/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    Label: ComponentFramework.PropertyTypes.StringProperty;
    IsSubsection: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    Alignment: ComponentFramework.PropertyTypes.EnumProperty<"left" | "center" | "right">;
    DividerShow: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    DividerColor: ComponentFramework.PropertyTypes.StringProperty;
    MarginTop: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    NotUsedProperty: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    NotUsedProperty?: string;
}
