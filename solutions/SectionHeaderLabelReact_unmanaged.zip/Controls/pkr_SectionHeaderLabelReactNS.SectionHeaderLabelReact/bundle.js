/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./SectionHeaderLabelReact/Label.tsx"
/*!*******************************************!*\
  !*** ./SectionHeaderLabelReact/Label.tsx ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LabelControl: () => (/* binding */ LabelControl)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass LabelControl extends react__WEBPACK_IMPORTED_MODULE_0__.Component {\n  constructor() {\n    super(...arguments);\n    this.containerRef = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createRef();\n  }\n  componentDidMount() {\n    this.disableRowPreviewMinHeight();\n  }\n  componentDidUpdate() {\n    this.disableRowPreviewMinHeight();\n  }\n  disableRowPreviewMinHeight() {\n    var _a;\n    var rowContainer = (_a = this.containerRef.current) === null || _a === void 0 ? void 0 : _a.closest('[data-preview_orientation=\"row\"]');\n    if (rowContainer) {\n      rowContainer.style.setProperty('min-height', '0', 'important');\n    }\n  }\n  render() {\n    var _a, _b;\n    var alignment = (_a = this.props.alignment) !== null && _a !== void 0 ? _a : 'left';\n    var marginTop = this.props.marginTop ? '4px' : undefined;\n    var fontSize = this.props.isSubsection ? '13px' : '14px';\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        width: '100%',\n        display: 'flex',\n        flexDirection: 'column',\n        marginTop\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Label, {\n      ref: this.containerRef,\n      role: \"heading\",\n      style: {\n        width: '100%',\n        display: 'block',\n        textAlign: alignment,\n        fontSize,\n        fontWeight: '600',\n        padding: '0px',\n        margin: '0px'\n      }\n    }, this.props.name), this.props.showDivider && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"hr\", {\n      style: {\n        width: '100%',\n        margin: '4px 0 0',\n        border: 'none',\n        borderTop: \"1px solid \".concat((_b = this.props.dividerColor) !== null && _b !== void 0 ? _b : '#e0e0e0')\n      }\n    })));\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SectionHeaderLabelReact/Label.tsx?\n}");

/***/ },

/***/ "./SectionHeaderLabelReact/index.ts"
/*!******************************************!*\
  !*** ./SectionHeaderLabelReact/index.ts ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   SectionHeaderLabelReact: () => (/* binding */ SectionHeaderLabelReact)\n/* harmony export */ });\n/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Label */ \"./SectionHeaderLabelReact/Label.tsx\");\n/* harmony import */ var _localization__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./localization */ \"./SectionHeaderLabelReact/localization.ts\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/// <reference types=\"powerapps-component-framework\" />\n\n\n\n/**\n * Coerces TwoOptions raw values to a real boolean. The form designer's\n * design-time preview can hand these through as the string \"false\"/\"true\"\n * rather than an actual boolean, which would otherwise be truthy.\n */\nfunction toBoolean(raw) {\n  if (typeof raw === 'string') {\n    return raw === 'true' || raw === '1';\n  }\n  return raw !== null && raw !== void 0 ? raw : false;\n}\nclass SectionHeaderLabelReact {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b;\n    var props = {\n      name: (0,_localization__WEBPACK_IMPORTED_MODULE_1__.resolveLocalizedLabel)(context.parameters.Label.raw, context.userSettings.languageId),\n      alignment: (_a = context.parameters.Alignment.raw) !== null && _a !== void 0 ? _a : 'left',\n      showDivider: toBoolean(context.parameters.DividerShow.raw),\n      dividerColor: (_b = context.parameters.DividerColor.raw) !== null && _b !== void 0 ? _b : '#e0e0e0',\n      marginTop: toBoolean(context.parameters.MarginTop.raw),\n      isSubsection: toBoolean(context.parameters.IsSubsection.raw)\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2__.createElement(_Label__WEBPACK_IMPORTED_MODULE_0__.LabelControl, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {};\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SectionHeaderLabelReact/index.ts?\n}");

/***/ },

/***/ "./SectionHeaderLabelReact/localization.ts"
/*!*************************************************!*\
  !*** ./SectionHeaderLabelReact/localization.ts ***!
  \*************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   resolveLocalizedLabel: () => (/* binding */ resolveLocalizedLabel)\n/* harmony export */ });\nfunction isLocalizedLabelArray(value) {\n  return Array.isArray(value) && value.every(entry => typeof entry === 'object' && entry !== null && typeof entry.languageCode === 'number' && typeof entry.label === 'string');\n}\n/**\n * Resolves the Label property value for the given user language.\n * Accepts either a plain string (used as-is) or a JSON-encoded array of\n * { languageCode, label } entries, matched against languageId with an\n * English (1033) fallback, then the first entry, then \"\".\n */\nfunction resolveLocalizedLabel(raw, languageId) {\n  if (!raw) {\n    return \"\";\n  }\n  var parsed;\n  try {\n    parsed = JSON.parse(raw);\n  } catch (_a) {\n    return raw;\n  }\n  if (!isLocalizedLabelArray(parsed)) {\n    return raw;\n  }\n  if (parsed.length === 0) {\n    return \"\";\n  }\n  var exactMatch = parsed.find(entry => entry.languageCode === languageId);\n  if (exactMatch) {\n    return exactMatch.label;\n  }\n  return parsed[0].label;\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SectionHeaderLabelReact/localization.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = (module) => {
/******/ 		const getter = module && module.__esModule ?
/******/ 			() => (module['default']) :
/******/ 			() => (module);
/******/ 		__webpack_require__.d(getter, { a: getter });
/******/ 		return getter;
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = __webpack_require__("./SectionHeaderLabelReact/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SectionHeaderLabelReactNS.SectionHeaderLabelReact', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SectionHeaderLabelReact);
} else {
	var SectionHeaderLabelReactNS = SectionHeaderLabelReactNS || {};
	SectionHeaderLabelReactNS.SectionHeaderLabelReact = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SectionHeaderLabelReact;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}